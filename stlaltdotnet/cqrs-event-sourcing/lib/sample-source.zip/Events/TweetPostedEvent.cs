﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Events
{
    [Serializable]
    public class TweetPostedEvent : Ncqrs.Domain.DomainEvent
    {
        public string Message { get; set; }
        public string Who { get; set; }
        public DateTime TimeStamp { get; set; }

        public TweetPostedEvent(string message, string who, DateTime timeStamp)
        {
            Message = message;
            Who = who;
            TimeStamp = timeStamp;
        }
    }
}
