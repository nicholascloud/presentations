﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ncqrs.Commanding.CommandExecution;
using Commands;
using Ncqrs.Domain;
using Domain;

namespace CommandExecutors
{
    public class PostNewTweetCommandExecutor : CommandExecutorBase<PostNewTweetCommand>
    {
        protected override void ExecuteInContext(IUnitOfWorkContext context, PostNewTweetCommand command)
        {
            var tweet = new Tweet(command.Message, command.Who);
            context.Accept();
        }
    }
}
