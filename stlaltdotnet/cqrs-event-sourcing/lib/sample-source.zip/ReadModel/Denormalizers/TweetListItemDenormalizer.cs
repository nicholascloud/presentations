﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Ncqrs.Eventing.Denormalization;
using Events;

namespace ReadModel.Denormalizers
{
    public class TweetListItemDenormalizer : IDenormalizer<TweetPostedEvent>
    {
        public void Handle(TweetPostedEvent evnt)
        {
            var context = new DataClassesDataContext();

            var item = new TweetListItem();
            item.Id = evnt.AggregateRootId;
            item.Message = evnt.Message;
            item.Who = evnt.Who;

            context.TweetListItems.InsertOnSubmit(item);
            context.SubmitChanges();
        }
    }
}
