﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Events;
using Ncqrs.Eventing.Denormalization;

namespace ReadModel.Denormalizers
{
    public class ListTweetCountDenormalizer : IDenormalizer<TweetPostedEvent>
    {
        public void Handle(TweetPostedEvent evnt)
        {
            var context = new DataClassesDataContext();

            var query = from i in context.TweetCountPerUsers
                        where i.Who == evnt.Who
                        select i;

            var item = query.FirstOrDefault();

            if(item == null)
            {
                item = new TweetCountPerUser();
                item.Who = evnt.Who;
                item.Count = 1;

                context.TweetCountPerUsers.InsertOnSubmit(item);
            }
            else
            {
                item.Count++;
            }

            context.SubmitChanges();
        }
    }
}
