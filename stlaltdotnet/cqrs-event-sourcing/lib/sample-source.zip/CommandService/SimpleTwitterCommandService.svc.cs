﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Commands;
using Ncqrs;
using Ncqrs.Commanding.ServiceModel;

namespace CommandService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "SimpleTwitterCommandService" in code, svc and config file together.
    public class SimpleTwitterCommandService : ISimpleTwitterCommandService
    {
        private static ICommandService _service;

        static SimpleTwitterCommandService()
        {
            Bootstrapper.BootUp();

            _service = NcqrsEnvironment.Get<ICommandService>();
        }

        public void Execute(PostNewTweetCommand command)
        {
            _service.Execute(command);
        }
    }
}
