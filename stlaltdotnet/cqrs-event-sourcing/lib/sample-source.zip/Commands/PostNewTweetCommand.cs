﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Commands
{
    public class PostNewTweetCommand : Ncqrs.Commanding.CommandBase
    {
        public string Message { get; set; }
        public string Who { get; set; }
    }
}
