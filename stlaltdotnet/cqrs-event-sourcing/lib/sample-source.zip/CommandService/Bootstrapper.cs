﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ncqrs.Config.StructureMap;
using Ncqrs.Commanding.ServiceModel;
using CommandExecutors;
using Ncqrs;
using Ncqrs.Eventing.Storage;
using Ncqrs.Eventing.Storage.SQL;
using Ncqrs.Eventing.ServiceModel.Bus;
using ReadModel.Denormalizers;
using Events;
using CommandService.Properties;

namespace CommandService
{
    public static class Bootstrapper
    {
        public static void BootUp()
        {
            var config = new StructureMapConfiguration((i) =>
            {
                i.For<ICommandService>().Use(InitializeCommandService());
                i.For<IEventStore>().Use(IntializeEventStore());
                i.For<IEventBus>().Use(InitializeEventBus());
            });

            NcqrsEnvironment.Configure(config);
        }

        private static IEventBus InitializeEventBus()
        {
            var bus = new InProcessEventBus();
            bus.RegisterHandler<TweetPostedEvent>(new TweetListItemDenormalizer());
            bus.RegisterHandler<TweetPostedEvent>(new ListTweetCountDenormalizer());

            return bus;
        }

        private static IEventStore IntializeEventStore()
        {
            var store = new SimpleMicrosoftSqlServerEventStore(Settings.Default.EventStoreConnectionString);
            return store;
        }

        private static ICommandService InitializeCommandService()
        {
            var service = new InProcessCommandService();
            service.RegisterExecutor(new PostNewTweetCommandExecutor());

            return service;
        }
    }
}