CREATE DATABASE [SimpleTweetReadModel]
GO
USE [SimpleTweetReadModel]
GO
CREATE TABLE [dbo].[TweetListItem](
	[Id] [uniqueidentifier] PRIMARY KEY,
	[Message] [nvarchar](255) NOT NULL,
	[Who] [nvarchar](255) NOT NULL
) ON [PRIMARY]
GO
CREATE TABLE [dbo].[TweetCountPerUser](
	[Who] [nvarchar](255) PRIMARY KEY,
	[Count] [bigint] NOT NULL
) ON [PRIMARY]
GO