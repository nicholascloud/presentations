﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Events;

namespace Domain
{
    public class Tweet : Ncqrs.Domain.AggregateRootMappedByConvention
    {
        private string _message;
        private string _who;
        private DateTime _timestamp;

        public Tweet(string message, string who)
        {
            var e = new TweetPostedEvent(message, who, DateTime.UtcNow);
            ApplyEvent(e);
        }

        protected void OnTweetPosted(TweetPostedEvent e)
        {
            Id = e.AggregateRootId;
            _message = e.Message;
            _who = e.Who;
            _timestamp = e.TimeStamp;
        }
    }
}
