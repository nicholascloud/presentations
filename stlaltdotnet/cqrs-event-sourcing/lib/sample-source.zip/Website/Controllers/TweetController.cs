﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Commands;
using Website.Commanding;
using ReadModel;

namespace Website.Controllers
{
    public class TweetController : Controller
    {
        //
        // GET: /Tweet/

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Add(PostNewTweetCommand command)
        {
            var client = new SimpleTwitterCommandServiceClient();
            client.Execute(command);

            return View();
        }

        public ActionResult List()
        {
            var context = new DataClassesDataContext();
            var query = from item in context.TweetListItems
                        select item;

            return View(query.ToList());
        }

        public ActionResult ListTweetCount()
        {
            var context = new DataClassesDataContext();
            var query = from item in context.TweetCountPerUsers
                        select item;

            return View(query.ToList());
        }
    }
}
